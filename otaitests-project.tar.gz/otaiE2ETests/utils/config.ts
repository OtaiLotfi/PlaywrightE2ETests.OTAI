export const appConfig = {
  url: 'https://marmelab.com/react-admin-demo/#/invoices',
  credentials: {
    username: process.env.APP_USERNAME || '',
    password: process.env.APP_PASSWORD || '',
  }
};